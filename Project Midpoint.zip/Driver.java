/*****************************************
** File:    Driver.java
** Project: CSCE 314 Project 1, Fall 2020
** Author:  Asa Hayes & Isabel Ramirez
** Date:    7 November, 2020
** Section: 502
** E-mail:  asahayes@tamu.edu + isabel.ramirez@tamu.edu
**
**   This file contains the main driver program for Project 1.
** This project intends to make a simple demonstration of the capabilities of
** Merkle Tree, in the context of a voting verification system. The end product
** should take in an input from the user and create a Merkle tree, with each 
** data block being a piece of voter information. It will then be compared to 
** an existing (premade for purposes of the project) tree to verify that the 
** information is correct.
***********************************************/

/*
** This program is a simple Java implementation of Merkle Trees. The leaves are represented 
** by leafNode objects (derived from the merkleNode class). Each leaf contains a hash value 
** determined by applying a hash function to a block of data input. Non-leaf nodes within the 
** tree are represented by parentNode objects (also derived from the merkleNode class). These 
** nodes contain a hash value determined by applying a hash function to a concatenation of the 
** node's children. The merkleTree class creates the structure of the tree from these merkleNodes,
** with the root of the tree being the hash root.
**
** The application of our implementation is to ensure that crucial information in ballots (first 
** and last name, address, government ID, and candidates/propositions voted for) is not tampered 
** with from the time the ballot was cast to when the ballot is counted. At the time of counting,
** the ballot's information will be separated into data blocks and used to construct a merkle tree
** with a hash root that represents its data in a secure and concise way. This root will be compared
** to the hash root computed when the ballot was cast. Any inconsistencies between the two hash roots
** indicate that the ballot was tampered with. This method is not based on any legitimate existing 
** method for ballot verification; it is just a idea to demonstrate the functionality of the Merkle 
** Tree that came to us from the election this week.
*/

import java.io.*;
import java.util.*;

public class Driver {
	
	public static void main(String[] args)
	{
		
//		FILE I/O: NOT COMPLETED		
//		Scanner infile = null;
//		try
//		{
//		infile = new Scanner(new FileReader("test.txt"));
//		} 
//		catch (FileNotFoundException e) 
//		{
//			System.out.println("File not found");
//			e.printStackTrace(); // prints error(s)
//			System.exit(0); // Exits entire program
//		}
//
//		
//		while(infile.hasNextLine())
//		{
//			String line = infile.nextLine();
//			// tokens separated by spaces (need commas)
//			StringTokenizer tokenizer = new StringTokenizer(line);
//			
//			ArrayList<String> personData = new ArrayList<String>();
//			
//			// You should know what you are reading in
//			personData.add(tokenizer.nextToken());
//			personData.add(tokenizer.nextToken());
//			personData.add(tokenizer.nextToken());
//			personData.add(tokenizer.nextToken());
//			
//			leafNode testLeaf = new leafNode(personData);
//		}
//		
//		infile.close();

		// Leaf Test 1
		// Each person's data is stored in an array list
		System.out.println("LEAF TEST 1");
		ArrayList<String> data1 = new ArrayList<String>();
		data1.add("John Doe");
		data1.add("A1B3C3D4");
		data1.add("5678 Main St., Houston, TX 44444");
		data1.add("01/01/1990");
		
		// Leaf node created from each person's data (each data block)
		leafNode leaf1 = new leafNode(data1);
		
		// testing instantiation a leaf node and using it's getter/setter methods
		System.out.println("Data block hashed by testLeaf: " + leaf1.getDataBlock());
		
		// retrieving the hash value of the leaf
		System.out.println("Leaf's hash value: " + leaf1.getHashValue());
		
		
		
		// Leaf Test 2
		System.out.println("\nLEAF TEST 2");
		ArrayList<String> data2 = new ArrayList<String>();
		data2.add("Jane Doe");
		data2.add("Z9Y8X7W6");
		data2.add("1234 Main St., Dallas, TX 22222");
		data2.add("12/12/1990");
		
		// Leaf node created from each person's data (each data block)
		leafNode leaf2 = new leafNode(data2);
		
		// testing instantiation a leaf node and using it's getter/setter methods
		System.out.println("Data block hashed by testLeaf: " + leaf2.getDataBlock());
		
		// retrieving the hash value of the leaf
		System.out.println("Leaf's hash value: " + leaf2.getHashValue());
		
		
		
		// Parent Node Test
		System.out.println("\nPARENT NODE TEST");
		// Parent node created form the 2 children nodes (person 1 and person 2's data)
		parentNode p1 = new parentNode(leaf1, leaf2);
		
		// retrieving hash value of the parent node
		System.out.println("Parent's hash value: " + p1.getHashValue());
		
		
		// Tree Test
		System.out.println("\nTREE TEST");
		merkleTree t1 = new merkleTree();
		t1.addNodes(leaf1, leaf2);
		System.out.println("Tree hash root value: " + t1.getHashRoot());
	}
  
}