/*****************************************
** File:    merkleNode.java
** Project: CSCE 314 Project 1, Fall 2020
** Author:  Asa Hayes & Isabel Ramirez
** Date:    7 November, 2020
** Section: 502
** E-mail:  asahayes@tamu.edu + isabel.ramirez@tamu.edu
**
**   This file defines the abstract class merkleNode
** which allows for the creation of nodes to compose the tree. 
***********************************************/

public abstract class merkleNode 
{
	public String hashValue;	// for storing the computed hash value of the node
	
	
	// retrieves the hash value of the node
	public String getHashValue() { return this.hashValue; }
	
	
	//hashFunction acts as the 'setter', as it takes in the invalue and hashes it to store the result
	protected abstract void hashFunction();
}