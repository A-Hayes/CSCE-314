/*****************************************
** File:    parentNode.java
** Project: CSCE 314 Project 1, Fall 2020
** Author:  Asa Hayes & Isabel Ramirez
** Date:    7 November, 2020
** Section: 502
** E-mail:  asahayes@tamu.edu + isabel.ramirez@tamu.edu
**
** This file implements the parentNode class derived from
** the merkleNode super class. Parent nodes require the left
** and right children as data members as well as a method that
** enables concatenation of children hashes.
***********************************************/

public class parentNode extends merkleNode
{
	protected merkleNode leftChild;		// left child of node
	protected merkleNode rightChild;	// right child of node

	
	// parent node constructor; initialized with children
	// hash value is calculated from those children's hash values
	parentNode(merkleNode left, merkleNode right)
	{
		this.leftChild = left;
		this.rightChild = right;
		hashFunction();
	}
	
	
	// getters for retrieving the left and right children nodes
  	public merkleNode getLeftChild() { return this.leftChild; }
  	public merkleNode getRightChild() { return this.rightChild; }
  
  	
  	// setters for the left and right children nodes
  	// for data synchronization if we find any discrepancies in the tree
  	public void setLeftChild(merkleNode child) { this.leftChild = child; }
  	public void setRightChild(merkleNode child) { this.rightChild = child; }
	
  	
  	// performs the hash function on a concatenation of the children nodes
	protected void hashFunction()
	{ 
		final StringBuilder concatStr = new StringBuilder();
		concatStr.append(leftChild.getHashValue());
		concatStr.append(rightChild.getHashValue());
		
		//System.out.println("Children's hash values concatenated: " + concatStr);
		this.hashValue = Integer.toString(concatStr.hashCode());
	}
}