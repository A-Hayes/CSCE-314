/*****************************************
** File:    merkleTree.java
** Project: CSCE 314 Project 1, Fall 2020
** Author:  Asa Hayes & Isabel Ramirez
** Date:    7 November, 2020
** Section: 502
** E-mail:  asahayes@tamu.edu + isabel.ramirez@tamu.edu
**
** This file contains the base merkle tree class from which the tree will
** constructed.
***********************************************/

public class merkleTree 
{
	private merkleNode root;		// hash root
	
	private merkleTree leftTree;	// left subtree
	private merkleTree rightTree;	// right subtree
	
	private merkleNode leftNode;	// left leaf
	private merkleNode rightNode;	// right leaf
	
	
	
	//buildTree serves as the setter for the merkleNode objects, root, leftTree, rightTree
	public void merkleTree()
	{
		root = null;
		leftNode = null;
		rightNode = null;
	}
	
	// adds a single node to the tree
	// since tree is initialized from the leaves, the initial parent node is the root
	protected void addNodes(merkleNode left, merkleNode right)
	{
		this.leftNode = left;
		this.rightNode = right;
		
		root = new parentNode(left, right);
	}
	
	// creates a single leaf node using the data input 
	protected void addTrees(merkleTree leftTree, merkleTree rightTree)
	{ 
		this.leftTree = leftTree;
		this.rightTree = rightTree;
		
		int lhashVal = leftTree.hashCode();
		int rhashVal = rightTree.hashCode();
		
		root.hashValue = Integer.toString((Integer.toString(lhashVal) + Integer.toString(rhashVal)).hashCode());
	}
	
	
	// getter for the hash value of the root of the MerkleTree
	public String getHashRoot() { return root.hashValue; }
	
	
	// displays the MerkleTree in a specified format
	public void displayTree() { return; }
	
	
	// getter for accessing the left node of the tree
	private merkleNode getLeftNode() { return leftNode; }
	
	
	// getter for accessing the right node of the tree
	private merkleNode getRightNode() { return rightNode; }
}