/*****************************************
** File:    leafNode.java
** Project: CSCE 314 Project 1, Fall 2020
** Author:  Asa Hayes & Isabel Ramirez
** Date:    7 November, 2020
** Section: 502
** E-mail:  asahayes@tamu.edu + isabel.ramirez@tamu.edu
**
** This file implements the leafNode class derived from
** the merkleNode super class. Leaf nodes require data
** blocks to perform the hash function to determine the 
** hash value.
***********************************************/
import java.util.ArrayList;

public class leafNode extends merkleNode
{
	private ArrayList<String> dataBlock;		// stores the data block input; only accessible to leaf

	
	// leaf constructor; initialized with a person's data
	leafNode(ArrayList<String> inData)
	{
		this.dataBlock = inData;
		hashFunction();
	}
	

	// loads the dataBlock data member from input
	public void setDataBlock(ArrayList<String> inData)
	{
		dataBlock.add(inData.get(0)); // full name
		dataBlock.add(inData.get(1)); // gov't id
		dataBlock.add(inData.get(2)); // address
		dataBlock.add(inData.get(3)); // DoB
		
		// hashValue is recalculated with new data
		hashFunction();
	}
	
	
	// retrieves the dataBlock member (person's data)
	public ArrayList<String> getDataBlock()
	{ 
		return this.dataBlock;
	}
	
	
	// calculates the hashValue by hashing all the person's data
	protected void hashFunction()
	{ 
		final StringBuilder dataString = new StringBuilder();
		
		for (int idx=0; idx<dataBlock.size(); idx++)
		{
			// each data is hashed and appended to a string
			dataString.append(dataBlock.get(idx).hashCode());
		}
		
		
		// string itself is hashed 
		this.hashValue = Integer.toString(dataString.hashCode());

	}
}