import java.util.ArrayList;
import java.util.Collections;

class Driver{
	
  public static void main(String[] args) {
    //Q1: Create/Instance 1 each of Animal & Vehicle Objects
	Address testAddr = new Address("TX", "Green St.", 77840, "College Station");
    Address testAddr2 = new Address("TN", "Blue St.", 84077, "Town");
    
    
    Animal testAni = new Animal(0, 5, 20, testAddr, "kibble");
   // System.out.println(testAni.toString());
    

    testAni.setType(2); 
    testAni.setAge(2);
    testAni.setWeight(1); 
    testAni.setAddress(testAddr2); 
    //System.out.println(testAni.toString());
    
    Vehicle testVe = new Vehicle(0, 17, 700, testAddr, "5K2399BV");
   // System.out.println(testVe.toString());

    testVe.setType(2);
    testVe.setlicensePlate("2H638HGF");
    testVe.setAge(6);
    testVe.setWeight(250); 
    testVe.setAddress(testAddr2); 
   // System.out.println(testVe.toString());
    
    
    //Q2: Create 4 instances of each class and place them in ArrayList
    ArrayList<Animal> animals = new ArrayList<Animal>();
    ArrayList<Vehicle> vehicles = new ArrayList<Vehicle>();
    
    
    Animal dog = new Animal(0, 2, 10, testAddr, "bone");
    Animal cat = new Animal(1, 2, 6, testAddr, "mouse");
    Animal fish = new Animal(2, 2, 2, testAddr, "fish food");
    Animal squirrel = new Animal(3, 7, 3, testAddr, "accorns");
    
    animals.add(dog);
    animals.add(cat);
    animals.add(fish);
    animals.add(squirrel);
    
//    System.out.println("Presorted animals:");
//    for (Animal ani: animals)
//    {
//    	System.out.println(ani.toString());
//    } 
//    
//    System.out.println();
//    
//    Collections.sort(animals);
//    
//    System.out.println("Sorted animals:");
//    for (Animal ani: animals)
//    {
//    	System.out.println(ani.toString());
//    }
    
    
    
    Vehicle car = new Vehicle(0, 2, 100, testAddr2, "AAA111");
    Vehicle truck = new Vehicle(1, 7, 150, testAddr2, "BBB222");
    Vehicle motorcycle = new Vehicle(2, 1, 50, testAddr2, "CCC333");
    Vehicle boat = new Vehicle(3, 2, 250, testAddr2, "DDD444");
    
    vehicles.add(car);
    vehicles.add(truck);
    vehicles.add(motorcycle);
    vehicles.add(boat);
    
//    System.out.println("presorted vehicles:");
//    for (Vehicle ve: vehicles)
//    {
//    	System.out.println(ve.toString());
//    } 
//    
//    System.out.println();
//    
//    Collections.sort(vehicles);
//    
//    System.out.println("Sorted vehicles:");
//    for (Vehicle ve: vehicles)
//    {
//    	System.out.println(ve.toString());
//    } 
//    
    
    
    
    // Q3

    Address testAddr3 = new Address("AK", "Yellow St.", 68168, "Place");
    Address testAddr4 = new Address("MN", "Red St.", 84077, "Land");
    Address testAddr5 = new Address("OH", "Orange St.", 77840, "Area");
    Address testAddr6 = new Address("AL", "Violet St.", 84077, "Metropolis");
    Address testAddr7 = new Address("RI", "Indigo St.", 77840, "Village");
    Address testAddr8 = new Address("VT", "Chartreuse St.", 84077, "Springfield");
    
    dog.setAddress(testAddr);
    cat.setAddress(testAddr2);
    fish.setAddress(testAddr3);
    squirrel.setAddress(testAddr4);
    car.setAddress(testAddr5);
    truck.setAddress(testAddr6);
    motorcycle.setAddress(testAddr7);
    boat.setAddress(testAddr8);

    
    
    ArrayList<Things> stuff = new ArrayList <Things>();
    stuff.add(dog);
    stuff.add(cat);
    stuff.add(fish);
    stuff.add(squirrel);
    stuff.add(car);
    stuff.add(truck);
    stuff.add(motorcycle);
    stuff.add(boat);
    
    System.out.println("list of objects:");
	  for (Object obj: stuff)
	  {
	  	System.out.println(obj.toString());
	  }
	  
	  Collections.sort(stuff);
	 System.out.println();
    System.out.println("Sorted alphabetically by state:");
	  for (Object obj: stuff)
	  {
	  	System.out.println(obj.toString());
	  }
	  
	}
}