public class Airplane extends Vehicle implements Warplane
{
	private String flightNumber;
	private String company;
	public String country;
	
	
	public String getFlightNumber() { return flightNumber; }
	public void setFlightNumber(String flightNumber) { this.flightNumber = flightNumber; }
	public String getCompany() { return company; }
	public void setCompany(String company) { this.company = company; }
	public String getMotor() { return motor; }
	public void setMotor(String motor) { this.motor = motor; }
	
	
	public void left() { System.out.println("airplane left"); }
	public void right() { System.out.println("airplane right"); }
	public void forward() { System.out.println("airplane forward"); }
	public void reverse() { System.out.println("airplane reverse"); }
	
	public void setCountry(String country) { this.country = country; }
	public String getCountry() { return country; }
	public void fireWeapon() { System.out.println("Airplane fires machine guns."); }
}