public abstract class Vehicle 
{
	private float speed;
	protected String motor;
	
	protected float getSpeed() { return speed; }
	protected void setSpeed(float speed) { this.speed = speed; }
	protected abstract String getMotor();
	protected abstract void setMotor(String motor);

	protected void left() { System.out.println("left"); } ;
	protected void right() { System.out.println("right"); } ;
	protected void forward() { System.out.println("forward"); } ;
	protected void reverse() { System.out.println("backward"); } ;
}
