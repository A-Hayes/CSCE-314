public class Driver {
	
	public static void main(String[] args) {
//		// Question 1
//		Vehicle v1 = new Vehicle();
//		v1.setSpeed(123);
//		System.out.println(v1.getSpeed());
		
		// Question 2
		Car c1 = new Car();
		c1.setSpeed(456);
		c1.setLicense("AAABBB12");
		System.out.println("Car speed: " + c1.getSpeed());
		System.out.println("License: " + c1.getLicense());
		c1.left();
		c1.right();
		c1.forward();
		c1.reverse();
		
		
		Airplane a1 = new Airplane();
		a1.setSpeed(789);
		a1.setFlightNumber("123456789");
		a1.setCompany("Company ABC");
		System.out.println("Airplane speed: " + a1.getSpeed());
		System.out.println("Airplane flight number: " + a1.getFlightNumber());
		System.out.println("Company: " + a1.getCompany());
		a1.left();
		a1.right();
		a1.forward();
		a1.reverse();
		
		
		// Question 3
		c1.setMotor("combustion");
		a1.setMotor("jet");
		System.out.println("Car motor: " + c1.getMotor());
		System.out.println("Airplane motor: " + a1.getMotor());
		
		
		// Question 4
		a1.setCountry("USA");
		System.out.println("Airplane's country: " + a1.getCountry());
		a1.fireWeapon();
	}
}