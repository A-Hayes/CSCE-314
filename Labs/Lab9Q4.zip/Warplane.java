public interface Warplane 
{
//	public String country = "NA";
	
	abstract void setCountry(String country);
	abstract String getCountry();
	
	abstract void fireWeapon();
	// just create a simple text message on what type of weapon this plane will fire
	
}