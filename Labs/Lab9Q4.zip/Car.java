public class Car extends Vehicle
{
	private String licensePlate;
	
	public String getLicense() { return licensePlate; }
	public void setLicense(String license) { this.licensePlate = license; }
	public String getMotor() { return motor; }
	public void setMotor(String motor) { this.motor = motor; }
	
	
	public void left() { System.out.println("car left"); }
	public void right() { System.out.println("car right"); }
	public void forward() { System.out.println("car forward"); }
	public void reverse() { System.out.println("car reverse"); }
	
}